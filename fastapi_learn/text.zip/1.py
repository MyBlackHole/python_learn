#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
-------------------------------------------------
   File Name:          1
   Description:
   Author:             Black Hole
   date:               2020/8/17
-------------------------------------------------
   Change Activity:    2020/8/17:
-------------------------------------------------
"""

__author__ = 'Black Hole'

# # 加载压缩文件，创建ZipFile对象
# # class zipfile.ZipFile(file[, mode[, compression[, allowZip64]]])
# # 参数file表示文件的路径或类文件对象(file-like object)
# # 参数mode指示打开zip文件的模式，默认值为'r'，表示读已经存在的zip文件，也可以为'w'或'a'，
# # 'w'表示新建一个zip文档或覆盖一个已经存在的zip文档，'a'表示将数据附加到一个现存的zip文档中
# # 参数compression表示在写zip文档时使用的压缩方法，它的值可以是zipfile. ZIP_STORED 或zipfile. ZIP_DEFLATED。
# # 如果要操作的zip文件大小超过2G，应该将allowZip64设置为True。
# file_dir = 'D:/text.zip'
# zipFile = zipfile.ZipFile(file_dir)
#
# # 01 ZipFile.infolist() 获取zip文档内所有文件的信息，返回一个zipfile.ZipInfo的列表
# print(zipFile.infolist())
# # 02 ZipFile.namelist() 获取zip文档内所有文件的名称列表
# print(zipFile.namelist())
# # 03 ZipFile.printdir() 将zip文档内的信息打印到控制台上
# print(zipFile.printdir())

# # 解压文件
# zipFile = zipfile.ZipFile(file_dir)
# for file in zipFile.namelist():
#     zipFile.extract(file, 'd:/Work')
# zipFile.close()


# 压缩

import zipfile

z_file = zipfile.ZipFile('text.zip', 'w')
z_file.write('1.py')
z_file.write('__init__.py')
z_file.close()

import os
import zipfile

source_dir = '/project/source'  # pwd查看绝对路径替换
zipname = '/project/target/compress_complete.zip'  # pwd查看绝对路径替换

startdir = source_dir  # 要压缩的文件夹路径
file_news = zipname  # 压缩后文件夹的名字
z = zipfile.ZipFile(file_news, 'w', zipfile.ZIP_DEFLATED)  # 参数一：文件夹名
for dirpath, dirnames, filenames in os.walk(startdir):
    fpath = dirpath.replace(startdir, '')
    fpath = fpath and fpath + os.sep or ''
    for filename in filenames:
        z.write(os.path.join(dirpath, filename), fpath + filename)
        print('压缩成功')
z.close()
s = '\u200b广元市苍溪县东溪镇扶贫办书记赵小伟与北岸村主任在扶贫易地扶贫搬迁建房中，欺下瞒上不管老百姓的生命安全，为建房包工头当保护伞，(因建房包工头' \
    '是村主任找的没有任何资值证件就给老百姓建房。)在建房过程中包工头多次出现质量问题，老百姓向政府相关部门反映，每次都是赵小伟来解决首先来把老百姓威胁:' \
    '要把老百姓打入黑恶势力，要收拾老百姓骂老百姓，赵小伟还说你家房子质量他敢用他头上的官帽担保，甚至没经过老百姓同意就把易建房款直接拨给建房包工头，' \
    '任由包工头瞎糊搞房子才修起一年，天花板和墙体四大角已裂缝。请上级领导严查扶贫中的腐败。地址苍旺公路管道\ud840\udc86附近1OO米(东溪镇至桥溪乡段)\u200b\u200b\u200b\u200b'
print(s)
